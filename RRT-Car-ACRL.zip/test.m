state.x = 0;
state.y = 0;

b.x = 20;
b.y = 20;

disp(action_select(state,b));